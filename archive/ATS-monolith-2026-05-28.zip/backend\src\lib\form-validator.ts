/**
 * Runtime validator for ApplicationFormSchema (Batch 4).
 *
 * Both the form *schema* (recruiter's design) and the *submission* (candidate's
 * response) are validated against Zod shapes so we never accept malformed JSON
 * on either side.
 */
import { z } from "zod";

// ── Field schema (used by builder save endpoint) ───────────────────────────
export const FormFieldTypeSchema = z.enum([
  "text", "textarea", "email", "phone", "number", "url",
  "date", "select", "multiselect", "radio", "checkbox",
  "file", "image",
]);

export const FormFieldSchema = z.object({
  id:          z.string().min(1).max(50),
  type:        FormFieldTypeSchema,
  label:       z.string().min(1).max(200),
  required:    z.boolean().default(false),
  placeholder: z.string().max(200).optional(),
  helpText:    z.string().max(500).optional(),
  // For select/multiselect/radio
  options:     z.array(z.string().min(1).max(100)).optional(),
  // For file/image
  fileTypes:   z.array(z.string()).optional(),  // [".pdf", ".docx"]
  maxSizeMb:   z.number().int().min(1).max(50).optional(),
  // Validation hints
  minLength:   z.number().int().min(0).optional(),
  maxLength:   z.number().int().min(1).optional(),
  pattern:     z.string().max(200).optional(),  // regex
  order:       z.number().int().min(0),
});

export type FormField = z.infer<typeof FormFieldSchema>;

export const FormFieldsArraySchema = z.array(FormFieldSchema).max(100);

/**
 * Validate a submission against a schema.
 * Returns { valid, errors, sanitized } — errors is a map of fieldId → message.
 */
export function validateSubmission(
  schemaFields: FormField[],
  submission: Record<string, unknown>
): { valid: boolean; errors: Record<string, string>; sanitized: Record<string, unknown> } {
  const errors: Record<string, string> = {};
  const sanitized: Record<string, unknown> = {};

  for (const field of schemaFields) {
    const raw = submission[field.id];
    const isEmpty = raw === undefined || raw === null || raw === "" ||
                    (Array.isArray(raw) && raw.length === 0);

    if (field.required && isEmpty) {
      errors[field.id] = `${field.label} is required.`;
      continue;
    }
    if (isEmpty) {
      sanitized[field.id] = null;
      continue;
    }

    switch (field.type) {
      case "email":
        if (typeof raw !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(raw)) {
          errors[field.id] = `${field.label} must be a valid email.`;
        } else {
          sanitized[field.id] = raw.toLowerCase().trim();
        }
        break;
      case "phone":
        if (typeof raw !== "string" || !/^[\d\s+()\-.]{6,30}$/.test(raw)) {
          errors[field.id] = `${field.label} must be a valid phone number.`;
        } else {
          sanitized[field.id] = raw.trim();
        }
        break;
      case "number":
        const n = Number(raw);
        if (Number.isNaN(n)) {
          errors[field.id] = `${field.label} must be a number.`;
        } else {
          sanitized[field.id] = n;
        }
        break;
      case "url":
        if (typeof raw !== "string") {
          errors[field.id] = `${field.label} must be a URL.`;
        } else {
          try { new URL(raw); sanitized[field.id] = raw.trim(); }
          catch { errors[field.id] = `${field.label} must be a valid URL.`; }
        }
        break;
      case "date":
        if (typeof raw !== "string" || isNaN(Date.parse(raw))) {
          errors[field.id] = `${field.label} must be a valid date.`;
        } else {
          sanitized[field.id] = raw;
        }
        break;
      case "select":
      case "radio":
        if (typeof raw !== "string") {
          errors[field.id] = `${field.label} must be a string.`;
        } else if (field.options && !field.options.includes(raw)) {
          errors[field.id] = `${field.label} must be one of: ${field.options.join(", ")}.`;
        } else {
          sanitized[field.id] = raw;
        }
        break;
      case "multiselect":
      case "checkbox":
        if (!Array.isArray(raw)) {
          errors[field.id] = `${field.label} must be an array.`;
        } else {
          const invalid = field.options
            ? raw.filter((v) => typeof v !== "string" || !field.options!.includes(v))
            : raw.filter((v) => typeof v !== "string");
          if (invalid.length > 0) {
            errors[field.id] = `${field.label} contains invalid options.`;
          } else {
            sanitized[field.id] = raw;
          }
        }
        break;
      case "text":
      case "textarea":
        if (typeof raw !== "string") {
          errors[field.id] = `${field.label} must be text.`;
        } else {
          if (field.minLength && raw.length < field.minLength) {
            errors[field.id] = `${field.label} must be at least ${field.minLength} characters.`;
          } else if (field.maxLength && raw.length > field.maxLength) {
            errors[field.id] = `${field.label} must be at most ${field.maxLength} characters.`;
          } else if (field.pattern && !new RegExp(field.pattern).test(raw)) {
            errors[field.id] = `${field.label} does not match the required format.`;
          } else {
            sanitized[field.id] = raw.trim();
          }
        }
        break;
      case "file":
      case "image":
        // File validation happens at multer/route level — here we just
        // record the filename reference if present.
        sanitized[field.id] = raw;
        break;
    }
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    sanitized,
  };
}

/** Default minimal form used when no schema is configured for a requisition. */
export const DEFAULT_FORM_FIELDS: FormField[] = [
  { id: "firstName", type: "text",  label: "First name", required: true, order: 0 },
  { id: "lastName",  type: "text",  label: "Last name",  required: true, order: 1 },
  { id: "email",     type: "email", label: "Email",      required: true, order: 2 },
  { id: "phone",     type: "phone", label: "Phone",      required: false, order: 3 },
  { id: "linkedinUrl", type: "url", label: "LinkedIn URL", required: false, order: 4 },
  { id: "coverLetter", type: "textarea", label: "Cover letter / Why this role?",
    required: false, placeholder: "Tell us why you're a great fit…", order: 5 },
  { id: "resume",    type: "file",  label: "Resume", required: true,
    fileTypes: [".pdf", ".doc", ".docx"], maxSizeMb: 10, order: 6 },
];
