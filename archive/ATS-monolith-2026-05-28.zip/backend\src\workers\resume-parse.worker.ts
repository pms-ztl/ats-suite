import { Worker, Job } from 'bullmq';
import { getRedisConnection, ResumeParseJobData, enqueueScreening } from '../lib/queue';
import { parseResume } from '../agents/resume-parser';
import { prisma } from '../utils/prisma';
import logger from '../lib/logger';

/**
 * Batch 2: increment processed/failed counters on the parent BulkUpload row
 * (if any) and mark COMPLETED / PARTIAL when all files have settled.
 */
async function tickBulkProgress(bulkUploadId: string | undefined, failed: boolean, errorMsg?: string, filename?: string) {
  if (!bulkUploadId) return;
  try {
    const row = await prisma.bulkUpload.findUnique({ where: { id: bulkUploadId } });
    if (!row) return;
    const processedDelta = failed ? 0 : 1;
    const failedDelta = failed ? 1 : 0;
    const newProcessed = row.processedFiles + processedDelta;
    const newFailed = row.failedFiles + failedDelta;
    const settled = newProcessed + newFailed;
    const isDone = settled >= row.totalFiles;

    const errors = failed && filename
      ? [...((row.errors as any[]) ?? []), { filename, error: errorMsg ?? 'unknown' }]
      : row.errors;

    await prisma.bulkUpload.update({
      where: { id: bulkUploadId },
      data: {
        processedFiles: newProcessed,
        failedFiles: newFailed,
        errors: errors as any,
        ...(isDone && {
          completedAt: new Date(),
          status: newFailed === 0
            ? 'COMPLETED'
            : newFailed === row.totalFiles
              ? 'FAILED'
              : 'PARTIAL',
        }),
      },
    });
  } catch (err) {
    logger.warn({ err, bulkUploadId }, 'tickBulkProgress failed');
  }
}

export function startResumeParseWorker(): Worker {
  const worker = new Worker<ResumeParseJobData>(
    'resume-parse',
    async (job: Job<ResumeParseJobData>) => {
      const { candidateId, tenantId, userId, resumeId, bulkUploadId } = job.data;

      logger.info({ jobId: job.id, candidateId, resumeId, bulkUploadId }, 'Processing resume parse job');

      // 1. Fetch the resume text
      const resume = await prisma.resume.findFirst({
        where: { id: resumeId, tenantId },
      });

      if (!resume?.extractedText) {
        await tickBulkProgress(bulkUploadId, true, 'No extracted text', resume?.fileName);
        throw new Error(`Resume ${resumeId} has no extracted text`);
      }

      // 2. Run AI parser
      try {
        const result = await parseResume({
          candidateId,
          tenantId,
          userId,
          resumeText: resume.extractedText,
        });

        logger.info({
          jobId: job.id,
          candidateId,
          runId: result.runId,
          skills: result.parsed.skills.length,
          cost: result.costUsd,
        }, 'Resume parsed successfully');

        // 3. Auto-trigger screening for each active application
        const applications = await prisma.application.findMany({
          where: { candidateId, tenantId, status: 'ACTIVE' },
          select: { requisitionId: true },
        });

        for (const app of applications) {
          await enqueueScreening({
            candidateId,
            requisitionId: app.requisitionId,
            tenantId,
            userId,
          });
        }

        // Tick bulk progress as success
        await tickBulkProgress(bulkUploadId, false);

        return { runId: result.runId, applicationsQueued: applications.length };
      } catch (err) {
        await tickBulkProgress(
          bulkUploadId,
          true,
          err instanceof Error ? err.message : String(err),
          resume.fileName
        );
        throw err;
      }
    },
    {
      connection: getRedisConnection(),
      concurrency: 3,
      limiter: { max: 10, duration: 60000 }, // Max 10 jobs per minute
    }
  );

  worker.on('completed', (job) => {
    logger.info({ jobId: job.id }, 'Resume parse job completed');
  });

  worker.on('failed', (job, err) => {
    logger.error({ jobId: job?.id, error: err.message, attempts: job?.attemptsMade }, 'Resume parse job failed');
  });

  return worker;
}
