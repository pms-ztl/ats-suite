/**
 * Notification bus (Batch 3).
 *
 * In-process EventEmitter that:
 *   1) Persists notifications to the DB (so they survive page reload)
 *   2) Fans out to any active SSE listeners for the recipient userId(s)
 *
 * For single-node deployments this is all we need. For horizontal scaling,
 * swap the EventEmitter for Redis pub/sub (BullMQ Redis already configured).
 */
import { EventEmitter } from "events";
import { prisma } from "../utils/prisma";
import logger from "./logger";
import type { NotificationType } from "../../node_modules/.prisma/client/enums";

// Single shared emitter for the whole process
const bus = new EventEmitter();
bus.setMaxListeners(1000); // many SSE clients

export interface NotificationInput {
  /** null = platform-wide (SUPER_ADMIN audience) */
  tenantId: string | null;
  /** null = broadcast to all users in tenant (or all super-admins if tenantId null) */
  userId:   string | null;
  type:     NotificationType;
  title:    string;
  body?:    string;
  link?:    string;
  metadata?: Record<string, unknown>;
}

/**
 * Persist a notification and emit to live SSE listeners.
 * Returns the saved record.
 */
export async function emitNotification(input: NotificationInput) {
  const saved = await prisma.notification.create({
    data: {
      tenantId: input.tenantId ?? null,
      userId:   input.userId ?? null,
      type:     input.type,
      title:    input.title,
      body:     input.body ?? null,
      link:     input.link ?? null,
      metadata: (input.metadata ?? {}) as any,
    },
  });

  // Fan-out:
  //  - If userId set → single channel
  //  - If userId null but tenantId set → all users in tenant (looked up below)
  //  - If both null → all SUPER_ADMIN users
  try {
    if (input.userId) {
      bus.emit(`user:${input.userId}`, saved);
    } else if (input.tenantId) {
      // Resolve tenant user IDs and emit individually
      const userIds = await prisma.user.findMany({
        where: { tenantId: input.tenantId, isActive: true },
        select: { id: true },
      });
      for (const u of userIds) bus.emit(`user:${u.id}`, saved);
    } else {
      // Platform-wide → SUPER_ADMIN users
      const supers = await prisma.user.findMany({
        where: { role: "SUPER_ADMIN", isActive: true },
        select: { id: true },
      });
      for (const u of supers) bus.emit(`user:${u.id}`, saved);
    }
  } catch (err) {
    logger.warn({ err, notificationId: saved.id }, "Notification fanout failed (DB record still saved)");
  }

  return saved;
}

/** Subscribe an SSE handler to a user's notification stream. Returns unsubscribe fn. */
export function subscribeToUser(
  userId: string,
  handler: (notification: any) => void
): () => void {
  const channel = `user:${userId}`;
  bus.on(channel, handler);
  return () => bus.off(channel, handler);
}

/** Test helper / health check. */
export function busListenerCount(userId: string): number {
  return bus.listenerCount(`user:${userId}`);
}
