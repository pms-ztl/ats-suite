/**
 * Custom application form schema CRUD (Batch 4 — recruiter side).
 *
 *  GET    /api/requisitions/:id/form   — fetch schema (or DEFAULT)
 *  PUT    /api/requisitions/:id/form   — save/replace schema (TENANT_ADMIN+)
 *  DELETE /api/requisitions/:id/form   — reset to default
 */
import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import {
  requireAuth, requireTenantAdmin, requireTenantUser, getTenantId,
} from "../middleware/auth";
import { AppError } from "../middleware/errorHandler";
import { ok } from "../lib/response";
import { prisma } from "../utils/prisma";
import { FormFieldsArraySchema, DEFAULT_FORM_FIELDS } from "../lib/form-validator";
import { PLAN_LIMITS } from "../lib/plan-limits";

const router = Router();
router.use(requireAuth);

const SaveSchema = z.object({
  name:   z.string().min(1).max(80).default("Default"),
  fields: FormFieldsArraySchema,
});

// ─── GET /api/requisitions/:id/form ────────────────────────────────────────
router.get(
  "/requisitions/:id/form",
  requireTenantUser,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      // Confirm requisition belongs to this tenant
      const requisition = await prisma.requisition.findFirst({
        where: { id, tenantId },
        select: { id: true },
      });
      if (!requisition) throw new AppError("NOT_FOUND", "Requisition not found", 404);

      const schema = await prisma.applicationFormSchema.findUnique({
        where: { requisitionId: id },
      });
      ok(res, {
        requisitionId: id,
        name: schema?.name ?? "Default (no custom form)",
        fields: schema?.fields ?? DEFAULT_FORM_FIELDS,
        isDefault: !schema,
        updatedAt: schema?.updatedAt ?? null,
      });
    } catch (err) { next(err); }
  }
);

// ─── PUT /api/requisitions/:id/form ────────────────────────────────────────
router.put(
  "/requisitions/:id/form",
  requireTenantAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      const body = SaveSchema.parse(req.body);

      // Plan gate: customForms feature
      const tenant = await prisma.tenant.findUnique({
        where: { id: tenantId },
        select: { plan: true },
      });
      if (!tenant) throw new AppError("NOT_FOUND", "Tenant not found", 404);
      if (!PLAN_LIMITS[tenant.plan].customForms) {
        throw new AppError(
          "PLAN_LIMIT",
          `Custom application forms are not included in the ${tenant.plan} plan. Upgrade to STARTER or higher.`,
          402
        );
      }

      // Verify requisition belongs to tenant
      const requisition = await prisma.requisition.findFirst({
        where: { id, tenantId },
        select: { id: true },
      });
      if (!requisition) throw new AppError("NOT_FOUND", "Requisition not found", 404);

      // Field IDs must be unique within the schema
      const idCounts = new Map<string, number>();
      for (const f of body.fields) {
        idCounts.set(f.id, (idCounts.get(f.id) ?? 0) + 1);
      }
      const dupes = [...idCounts.entries()].filter(([, n]) => n > 1).map(([k]) => k);
      if (dupes.length > 0) {
        throw new AppError("VALIDATION_ERROR", `Duplicate field IDs: ${dupes.join(", ")}`, 400);
      }

      // Upsert
      const saved = await prisma.applicationFormSchema.upsert({
        where: { requisitionId: id },
        create: {
          tenantId,
          requisitionId: id,
          name: body.name,
          fields: body.fields as any,
        },
        update: {
          name: body.name,
          fields: body.fields as any,
        },
      });
      ok(res, saved);
    } catch (err) { next(err); }
  }
);

// ─── DELETE /api/requisitions/:id/form ─────────────────────────────────────
router.delete(
  "/requisitions/:id/form",
  requireTenantAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      await prisma.applicationFormSchema.deleteMany({
        where: { requisitionId: id, tenantId },
      });
      ok(res, { reset: true, message: "Form reset to default." });
    } catch (err) { next(err); }
  }
);

export default router;
