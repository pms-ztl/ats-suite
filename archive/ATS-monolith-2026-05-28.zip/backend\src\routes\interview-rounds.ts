/**
 * Tenant-configurable interview rounds (Batch 5).
 *
 *  GET    /api/requisitions/:id/rounds              — list rounds for a requisition
 *  POST   /api/requisitions/:id/rounds              — add a round
 *  PATCH  /api/rounds/:id                           — edit
 *  DELETE /api/rounds/:id                           — remove
 *  PUT    /api/requisitions/:id/rounds/reorder      — bulk reorder
 *  POST   /api/applications/:id/advance-round       — move candidate to next round
 *                                                     (optionally auto-creates Interview)
 */
import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import {
  requireAuth, requireTenantUser, requireTenantAdmin, getTenantId,
} from "../middleware/auth";
import { AppError } from "../middleware/errorHandler";
import { ok, created } from "../lib/response";
import { prisma } from "../utils/prisma";
import { PLAN_LIMITS } from "../lib/plan-limits";

const router = Router();
router.use(requireAuth);

const INTERVIEW_TYPES = ["PHONE_SCREEN", "TECHNICAL", "BEHAVIORAL", "PANEL", "FINAL"] as const;
const USER_ROLES = ["RECRUITER", "HIRING_MANAGER", "INTERVIEWER", "ADMIN", "COMPLIANCE_OFFICER"] as const;

const RoundSchema = z.object({
  name:                z.string().min(1).max(120),
  interviewType:       z.enum(INTERVIEW_TYPES),
  durationMinutes:     z.number().int().min(15).max(480).default(60),
  instructions:        z.string().max(2000).optional(),
  autoAdvanceOnPass:   z.boolean().default(false),
  defaultPanelistRole: z.enum(USER_ROLES).optional(),
});

// ─── plan gate helper ──────────────────────────────────────────────────────
async function assertConfigurableRounds(tenantId: string) {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
    select: { plan: true },
  });
  if (!tenant) throw new AppError("NOT_FOUND", "Tenant not found", 404);
  if (!PLAN_LIMITS[tenant.plan].configurableRounds) {
    throw new AppError(
      "PLAN_LIMIT",
      `Configurable interview rounds are not included in the ${tenant.plan} plan. Upgrade to STARTER or higher.`,
      402
    );
  }
}

// ─── GET /api/requisitions/:id/rounds ──────────────────────────────────────
router.get(
  "/requisitions/:id/rounds",
  requireTenantUser,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      const requisition = await prisma.requisition.findFirst({
        where: { id, tenantId },
        select: { id: true },
      });
      if (!requisition) throw new AppError("NOT_FOUND", "Requisition not found", 404);

      const rounds = await prisma.interviewRound.findMany({
        where: { requisitionId: id, tenantId },
        orderBy: { order: "asc" },
      });
      ok(res, rounds);
    } catch (err) { next(err); }
  }
);

// ─── POST /api/requisitions/:id/rounds ─────────────────────────────────────
router.post(
  "/requisitions/:id/rounds",
  requireTenantAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      await assertConfigurableRounds(tenantId);

      const requisition = await prisma.requisition.findFirst({
        where: { id, tenantId },
        select: { id: true },
      });
      if (!requisition) throw new AppError("NOT_FOUND", "Requisition not found", 404);

      const body = RoundSchema.parse(req.body);
      const lastOrder = await prisma.interviewRound.findFirst({
        where: { requisitionId: id },
        orderBy: { order: "desc" },
        select: { order: true },
      });
      const order = (lastOrder?.order ?? 0) + 1;

      const round = await prisma.interviewRound.create({
        data: {
          tenantId,
          requisitionId: id,
          name: body.name,
          interviewType: body.interviewType as any,
          durationMinutes: body.durationMinutes,
          instructions: body.instructions ?? null,
          autoAdvanceOnPass: body.autoAdvanceOnPass,
          defaultPanelistRole: body.defaultPanelistRole as any,
          order,
        },
      });
      created(res, round);
    } catch (err) { next(err); }
  }
);

// ─── PATCH /api/rounds/:id ─────────────────────────────────────────────────
router.patch(
  "/rounds/:id",
  requireTenantAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      const body = RoundSchema.partial().parse(req.body);

      const existing = await prisma.interviewRound.findFirst({ where: { id, tenantId } });
      if (!existing) throw new AppError("NOT_FOUND", "Round not found", 404);

      const updated = await prisma.interviewRound.update({
        where: { id },
        data: {
          ...(body.name !== undefined && { name: body.name }),
          ...(body.interviewType !== undefined && { interviewType: body.interviewType as any }),
          ...(body.durationMinutes !== undefined && { durationMinutes: body.durationMinutes }),
          ...(body.instructions !== undefined && { instructions: body.instructions }),
          ...(body.autoAdvanceOnPass !== undefined && { autoAdvanceOnPass: body.autoAdvanceOnPass }),
          ...(body.defaultPanelistRole !== undefined && { defaultPanelistRole: body.defaultPanelistRole as any }),
        },
      });
      ok(res, updated);
    } catch (err) { next(err); }
  }
);

// ─── DELETE /api/rounds/:id ────────────────────────────────────────────────
router.delete(
  "/rounds/:id",
  requireTenantAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      const existing = await prisma.interviewRound.findFirst({ where: { id, tenantId } });
      if (!existing) throw new AppError("NOT_FOUND", "Round not found", 404);
      // Soft delete by detaching interviews — we keep historical data intact
      await prisma.$transaction([
        prisma.interview.updateMany({ where: { roundId: id }, data: { roundId: null } }),
        prisma.interviewRound.delete({ where: { id } }),
      ]);
      ok(res, { deleted: true });
    } catch (err) { next(err); }
  }
);

// ─── PUT /api/requisitions/:id/rounds/reorder ──────────────────────────────
const ReorderSchema = z.object({
  order: z.array(z.string().uuid()).min(1),
});

router.put(
  "/requisitions/:id/rounds/reorder",
  requireTenantAdmin,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const id = req.params["id"] as string;
      const { order } = ReorderSchema.parse(req.body);

      // Verify all IDs belong to this requisition
      const rounds = await prisma.interviewRound.findMany({
        where: { requisitionId: id, tenantId, id: { in: order } },
        select: { id: true },
      });
      if (rounds.length !== order.length) {
        throw new AppError("VALIDATION_ERROR", "Some round IDs do not belong to this requisition", 400);
      }

      // Two-phase update: bump to negative numbers first (avoid unique-constraint
      // collisions on @@unique([requisitionId, order])), then to final.
      await prisma.$transaction([
        ...order.map((roundId, i) =>
          prisma.interviewRound.update({
            where: { id: roundId },
            data: { order: -(i + 1) },          // temp negative
          })
        ),
        ...order.map((roundId, i) =>
          prisma.interviewRound.update({
            where: { id: roundId },
            data: { order: i + 1 },             // final 1-based
          })
        ),
      ]);

      ok(res, { reordered: order.length });
    } catch (err) { next(err); }
  }
);

// ─── POST /api/applications/:id/advance-round ──────────────────────────────
// Move candidate to next round. Delegates to round-progression.ts so the same
// code path is shared with the auto-advance worker (Batch 6 Gap 1).
import { advanceApplicationToNextRound } from "../lib/round-progression";

router.post(
  "/applications/:id/advance-round",
  requireTenantUser,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const tenantId = getTenantId(req);
      const applicationId = req.params["id"] as string;
      const userId = (req as any).user?.id;

      const result = await advanceApplicationToNextRound({
        applicationId,
        tenantId,
        triggeredBy: "user",
        triggeredByUserId: userId,
      });

      if (result.reason === "no_more_rounds") {
        throw new AppError(
          "VALIDATION_ERROR",
          "This application has already completed the final round for its requisition.",
          400
        );
      }

      ok(res, {
        interview: result.interview,
        round: result.round,
        assignedPanelistId: result.assignedPanelistId,
        warning: result.reason === "no_panelist_available"
          ? "No active user with the round's default panelist role — please assign manually."
          : null,
      });
    } catch (err) { next(err); }
  }
);

export default router;
