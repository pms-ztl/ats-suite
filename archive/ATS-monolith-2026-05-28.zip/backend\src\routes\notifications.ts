/**
 * Notifications API (Batch 3 — significantly expanded from email-only).
 *
 * Keeps existing email-send endpoint (used by legacy code), adds:
 *   GET    /api/notifications                List user's notifications (tenant-scoped)
 *   GET    /api/notifications/unread-count   Just the unread count
 *   PATCH  /api/notifications/:id/read       Mark one as read
 *   POST   /api/notifications/read-all       Mark all as read
 *   GET    /api/notifications/stream         SSE real-time push
 */
import { Router, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { requireAuth, getTenantId } from '../middleware/auth';
import { ok } from '../lib/response';
import { sendEmail, EmailTemplates } from '../lib/mailer';
import { AppError } from '../middleware/errorHandler';
import { prisma } from '../utils/prisma';
import { subscribeToUser } from '../lib/notification-bus';
import { AuthRequest } from '../types';
import logger from '../lib/logger';

const router = Router();
router.use(requireAuth);

// ─── Helpers ───────────────────────────────────────────────────────────────
/**
 * Build a Prisma WHERE clause that scopes notifications to:
 *  - SUPER_ADMIN: their own user notifications + all platform-wide (tenantId=null)
 *                 notifications + tenant-broadcast where they are super-admin
 *  - other roles: their own user notifications + tenant-broadcast in their tenant
 *                 (NEVER platform-wide tenantId=null)
 */
function userScopeWhere(req: Request): any {
  const auth = req as AuthRequest;
  const userId = auth.user!.id;
  const tenantId = auth.user!.tenantId;
  const role = auth.user!.role;

  if (role === 'SUPER_ADMIN') {
    return {
      OR: [
        { userId },                                // addressed directly to me
        { tenantId: null },                        // all platform-wide notifs
        { tenantId, userId: null },                // tenant broadcast in my tenant
      ],
    };
  }
  // Non-super-admin: own + tenant-broadcast, NEVER platform-wide
  return {
    OR: [
      { userId, tenantId },
      { tenantId, userId: null },                 // tenant broadcast
    ],
  };
}

// ─── GET /api/notifications ────────────────────────────────────────────────
router.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const limit = Math.min(Number(req.query['limit']) || 50, 200);
    const unreadOnly = req.query['unread'] === 'true';
    const where = userScopeWhere(req);
    if (unreadOnly) where.AND = [{ readAt: null }];
    const rows = await prisma.notification.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    ok(res, rows);
  } catch (err) { next(err); }
});

// ─── GET /api/notifications/unread-count ───────────────────────────────────
router.get('/unread-count', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const where = { ...userScopeWhere(req), readAt: null };
    const count = await prisma.notification.count({ where });
    ok(res, { count });
  } catch (err) { next(err); }
});

// ─── PATCH /api/notifications/:id/read ────────────────────────────────────
router.patch('/:id/read', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params['id'] as string;
    // Use scope-safe update
    const where = { ...userScopeWhere(req), id };
    const result = await prisma.notification.updateMany({
      where,
      data: { readAt: new Date() },
    });
    if (result.count === 0) throw new AppError('NOT_FOUND', 'Notification not found', 404);
    ok(res, { marked: result.count });
  } catch (err) { next(err); }
});

// ─── POST /api/notifications/read-all ──────────────────────────────────────
router.post('/read-all', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const where = { ...userScopeWhere(req), readAt: null };
    const result = await prisma.notification.updateMany({
      where,
      data: { readAt: new Date() },
    });
    ok(res, { marked: result.count });
  } catch (err) { next(err); }
});

// ─── GET /api/notifications/stream ─────────────────────────────────────────
// Server-Sent Events: client opens an EventSource, receives event: notification
// for each real-time push. Falls back to polling on the frontend if this errors.
router.get('/stream', async (req: Request, res: Response, _next: NextFunction) => {
  const auth = req as AuthRequest;
  if (!auth.user) {
    res.status(401).end();
    return;
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // disable nginx buffering
  res.flushHeaders?.();

  // Initial hello
  res.write(`event: hello\ndata: ${JSON.stringify({ userId: auth.user.id, at: new Date().toISOString() })}\n\n`);

  // Keep-alive ping every 25s (well under typical proxy timeout of 60s)
  const keepAlive = setInterval(() => {
    res.write(`: ping\n\n`);
  }, 25_000);

  const unsubscribe = subscribeToUser(auth.user.id, (notif) => {
    try {
      res.write(`event: notification\ndata: ${JSON.stringify(notif)}\n\n`);
    } catch (err) {
      logger.warn({ err }, 'SSE write failed');
    }
  });

  req.on('close', () => {
    clearInterval(keepAlive);
    unsubscribe();
  });
});

// ═════════════════════════════════════════════════════════════════════════
// Legacy email endpoints (kept for backwards compat)
// ═════════════════════════════════════════════════════════════════════════
const SendEmailSchema = z.object({
  to: z.string().email().or(z.array(z.string().email())),
  templateType: z.enum(['candidateInvite', 'offerLetter', 'applicationReceived', 'interviewReminder']),
  params: z.record(z.string(), z.string()),
});

router.post('/email/send', async (req, res, next) => {
  try {
    const body = SendEmailSchema.parse(req.body);
    const { to, templateType, params } = body;

    let template: { subject: string; html: string };
    switch (templateType) {
      case 'candidateInvite':
        template = EmailTemplates.candidateInvite(params['candidateName']!, params['interviewDate']!, params['link']!);
        break;
      case 'offerLetter':
        template = EmailTemplates.offerLetter(params['candidateName']!, params['role']!, params['link']!);
        break;
      case 'applicationReceived':
        template = EmailTemplates.applicationReceived(params['candidateName']!, params['role']!);
        break;
      case 'interviewReminder':
        template = EmailTemplates.interviewReminder(params['candidateName']!, params['interviewDate']!, params['location']!);
        break;
      default:
        throw new AppError('INVALID_TEMPLATE', 'Unknown email template', 400);
    }

    await sendEmail({ to, ...template });
    return ok(res, { sent: true, to, subject: template.subject });
  } catch (err) { return next(err); }
});

router.get('/templates', async (_req, res, next) => {
  try {
    return ok(res, {
      templates: [
        { id: 'candidateInvite', name: 'Interview Invitation', params: ['candidateName', 'interviewDate', 'link'] },
        { id: 'offerLetter', name: 'Offer Letter', params: ['candidateName', 'role', 'link'] },
        { id: 'applicationReceived', name: 'Application Received', params: ['candidateName', 'role'] },
        { id: 'interviewReminder', name: 'Interview Reminder', params: ['candidateName', 'interviewDate', 'location'] },
      ],
    });
  } catch (err) { return next(err); }
});

export default router;
