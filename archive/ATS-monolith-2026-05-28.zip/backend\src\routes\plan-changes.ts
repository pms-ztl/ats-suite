/**
 * Plan upgrade request workflow (Batch 3 — tenant side).
 *
 *  POST   /api/tenants/plan-change-request    Tenant admin requests upgrade
 *  GET    /api/tenants/plan-change-requests   Lists own tenant's history
 *  DELETE /api/tenants/plan-change-requests/:id   Cancel own pending request
 *
 * Super-admin approval endpoints live in super-admin.ts.
 */
import { Router, Request, Response, NextFunction } from 'express';
import { z } from 'zod';
import { requireAuth, requireTenantAdmin, getTenantId } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';
import { ok, created } from '../lib/response';
import { prisma } from '../utils/prisma';
import { emitNotification } from '../lib/notification-bus';
import { AuthRequest } from '../types';

const router = Router();
router.use(requireAuth);

const RequestSchema = z.object({
  toPlan: z.enum(['FREE', 'STARTER', 'PROFESSIONAL', 'ENTERPRISE']),
  reason: z.string().max(500).optional(),
});

// ─── POST /api/tenants/plan-change-request ─────────────────────────────────
router.post('/plan-change-request', requireTenantAdmin, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const tenantId = getTenantId(req);
    const userId = (req as AuthRequest).user!.id;
    const { toPlan, reason } = RequestSchema.parse(req.body);

    const tenant = await prisma.tenant.findUnique({ where: { id: tenantId }, select: { plan: true, name: true } });
    if (!tenant) throw new AppError('NOT_FOUND', 'Tenant not found', 404);

    if (tenant.plan === toPlan) {
      throw new AppError('VALIDATION_ERROR', `Tenant is already on the ${toPlan} plan.`, 400);
    }

    // Reject if there's already a pending request for this tenant
    const existing = await prisma.planChangeRequest.findFirst({
      where: { tenantId, status: 'PENDING' },
    });
    if (existing) {
      throw new AppError(
        'CONFLICT',
        `A plan change request is already pending (id=${existing.id}). Cancel it before submitting a new one.`,
        409
      );
    }

    const request = await prisma.planChangeRequest.create({
      data: {
        tenantId,
        fromPlan: tenant.plan,
        toPlan: toPlan as any,
        reason: reason ?? null,
        requestedByUserId: userId,
        status: 'PENDING',
      },
    });

    // Fan-out: notify all SUPER_ADMIN users
    await emitNotification({
      tenantId: null,                // platform-wide notification
      userId: null,                  // broadcast to all super-admins
      type: 'PLAN_CHANGE_REQUESTED',
      title: `${tenant.name} requested upgrade: ${tenant.plan} → ${toPlan}`,
      body: reason ?? undefined,
      link: '/admin/plan-requests',
      metadata: { tenantId, requestId: request.id, fromPlan: tenant.plan, toPlan },
    });

    return created(res, request);
  } catch (err) {
    return next(err);
  }
});

// ─── GET /api/tenants/plan-change-requests ─────────────────────────────────
router.get('/plan-change-requests', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const tenantId = getTenantId(req);
    const rows = await prisma.planChangeRequest.findMany({
      where: { tenantId },
      orderBy: { requestedAt: 'desc' },
      take: 50,
    });
    ok(res, rows);
  } catch (err) {
    return next(err);
  }
});

// ─── DELETE /api/tenants/plan-change-requests/:id ──────────────────────────
router.delete('/plan-change-requests/:id', requireTenantAdmin, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const tenantId = getTenantId(req);
    const id = req.params['id'] as string;
    const row = await prisma.planChangeRequest.findFirst({ where: { id, tenantId } });
    if (!row) throw new AppError('NOT_FOUND', 'Request not found', 404);
    if (row.status !== 'PENDING') {
      throw new AppError('VALIDATION_ERROR', `Cannot cancel a request in ${row.status} state.`, 400);
    }
    await prisma.planChangeRequest.update({
      where: { id },
      data: { status: 'CANCELLED' },
    });
    ok(res, { cancelled: true });
  } catch (err) {
    return next(err);
  }
});

export default router;
