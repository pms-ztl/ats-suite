-- AlterTable
ALTER TABLE "Application" ADD COLUMN     "formResponses" JSONB;

-- CreateTable
CREATE TABLE "ApplicationFormSchema" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "requisitionId" TEXT,
    "name" TEXT NOT NULL DEFAULT 'Default',
    "fields" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ApplicationFormSchema_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ApplicationFormSchema_requisitionId_key" ON "ApplicationFormSchema"("requisitionId");

-- CreateIndex
CREATE INDEX "ApplicationFormSchema_tenantId_idx" ON "ApplicationFormSchema"("tenantId");

-- AddForeignKey
ALTER TABLE "ApplicationFormSchema" ADD CONSTRAINT "ApplicationFormSchema_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
