import { Request, Response, NextFunction } from "express";
import { AppError } from "./errorHandler";
import { signAccessToken, verifyToken as _verifyToken } from "../lib/jwt";
import { AuthUser } from "../types";
import { setTenantContext } from "./prisma-rls";
import { prisma } from "../utils/prisma";

// Express Request is already augmented with user?: AuthUser in types/index.ts

// ── Backward-compat: generateToken used by app.ts login route ────────────────
export function generateToken(user: AuthUser): string {
  return signAccessToken({
    sub: user.id,
    email: user.email,
    role: user.role,
    tenantId: user.tenantId,
  });
}

// ── requireAuth ───────────────────────────────────────────────────────────────
export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    const cookieToken = req.cookies?.["ats-token"] as string | undefined;

    const raw = authHeader?.startsWith("Bearer ")
      ? authHeader.slice(7)
      : cookieToken;

    if (!raw) throw new AppError("UNAUTHORIZED", "Authentication required", 401);

    const payload = _verifyToken(raw);

    if (payload.type !== "access") {
      throw new AppError("UNAUTHORIZED", "Invalid token type", 401);
    }

    req.user = {
      id: payload.sub,
      email: payload.email,
      role: payload.role,
      tenantId: payload.tenantId,
      firstName: (payload as any).firstName ?? "",
      lastName: (payload as any).lastName ?? "",
    };

    // Set RLS tenant context so Postgres enforces row-level isolation
    if (req.user.tenantId) {
      try {
        await setTenantContext(prisma, req.user.tenantId);
      } catch {
        // RLS context setting is best-effort; app-layer filtering still applies
      }
    }

    next();
  } catch (err) {
    if (err instanceof AppError) return next(err);
    next(new AppError("UNAUTHORIZED", "Invalid or expired token", 401));
  }
}

// ── Backward-compat alias: app.ts uses `authenticate` ────────────────────────
export const authenticate = requireAuth;

// ── requireRole ───────────────────────────────────────────────────────────────
export function requireRole(...roles: string[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user)
      return next(new AppError("UNAUTHORIZED", "Authentication required", 401));
    if (!roles.includes(req.user.role)) {
      return next(
        new AppError(
          "FORBIDDEN",
          `Role '${req.user.role}' is not allowed. Required: ${roles.join(", ")}`,
          403
        )
      );
    }
    next();
  };
}

// Backward-compat alias used by existing engine routes
export const authorize = requireRole;

// ── requireTenant ─────────────────────────────────────────────────────────────
export function requireTenant(
  req: Request,
  _res: Response,
  next: NextFunction
) {
  if (!req.user?.tenantId) {
    return next(new AppError("FORBIDDEN", "Tenant context required", 403));
  }
  next();
}

// ── getTenantId ───────────────────────────────────────────────────────────────
// Helper to scope Prisma queries to the authenticated tenant
export function getTenantId(req: Request): string {
  if (!req.user?.tenantId)
    throw new AppError("FORBIDDEN", "Tenant context required", 403);
  return req.user.tenantId;
}

// ═══════════════════════════════════════════════════════════════════════════
// 3-TIER PaaS HELPERS (Batch 1)
// ARCHITECTURE NOTE: We did NOT rename UserRole.ADMIN → TENANT_ADMIN to avoid a
// breaking change across 38+ files. Treat ADMIN as semantically TENANT_ADMIN.
// ═══════════════════════════════════════════════════════════════════════════

/** Tier 1: platform-level (sees all tenants). */
export const requireSuperAdmin = requireRole("SUPER_ADMIN");

/** Tier 2: tenant administrator (the customer's owner account). */
export const requireTenantAdmin = requireRole("ADMIN");

/**
 * Tier 3: any tenant staff (ADMIN, RECRUITER, HIRING_MANAGER, INTERVIEWER).
 * COMPLIANCE_OFFICER is excluded — it has its own permission lattice.
 */
export const requireTenantUser = requireRole(
  "ADMIN",
  "RECRUITER",
  "HIRING_MANAGER",
  "INTERVIEWER"
);

/** Convenience: SUPER_ADMIN OR TENANT_ADMIN — used by some admin-only UIs. */
export const requireAnyAdmin = requireRole("SUPER_ADMIN", "ADMIN");

// ── Seat enforcement helper ─────────────────────────────────────────────────
import { PLAN_LIMITS, canAddSeats } from "../lib/plan-limits";

/**
 * Throws PLAN_LIMIT 402 if the tenant cannot accept N more active users.
 * Use inside route handlers BEFORE creating the user record.
 */
export async function assertSeatAvailable(
  tenantId: string,
  addingN = 1
): Promise<void> {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
    select: { plan: true },
  });
  if (!tenant) throw new AppError("NOT_FOUND", "Tenant not found", 404);

  const activeUserCount = await prisma.user.count({
    where: { tenantId, isActive: true },
  });

  if (!canAddSeats(tenant.plan, activeUserCount, addingN)) {
    const limit = PLAN_LIMITS[tenant.plan].seats;
    throw new AppError(
      "PLAN_LIMIT",
      `Plan ${tenant.plan} allows max ${limit} seats. You have ${activeUserCount}. Upgrade your plan to invite more teammates.`,
      402
    );
  }
}
