/**
 * POST /api/auth/register-company
 * Self-serve SaaS onboarding: creates a new Tenant + the first ADMIN user.
 * No auth required (public endpoint).
 */
import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import prisma from "../utils/prisma";
import { hashPassword } from "../lib/password";
import { generateToken, } from "../middleware/auth";
import { signRefreshToken } from "../lib/jwt";
import { AppError } from "../middleware/errorHandler";
import { ok } from "../lib/response";

const router = Router();

const RegisterCompanySchema = z.object({
  // Company info
  orgName:     z.string().min(2).max(100),
  industry:    z.string().optional(),
  companySize: z.string().optional(),
  website:     z.string().url().optional().or(z.literal("")),
  plan:        z.enum(["FREE", "STARTER", "PROFESSIONAL", "ENTERPRISE"]).default("FREE"),
  // Admin user
  firstName:   z.string().min(1).max(80),
  lastName:    z.string().min(1).max(80),
  email:       z.string().email(),
  password:    z.string().min(8),
});

/** Turn "Acme Corp" → "acme-corp-1738" (unique slug) */
function slugify(name: string): string {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") +
    "-" +
    Date.now().toString(36)
  );
}

const COOKIE_OPTS = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  path: "/",
};

// POST /api/auth/register-company
router.post("/", async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const body = RegisterCompanySchema.parse(req.body);

    // Check email uniqueness across all tenants
    const existing = await prisma.user.findFirst({
      where: { email: body.email.toLowerCase() },
    });
    if (existing) {
      throw new AppError("CONFLICT", "An account with this email already exists.", 409);
    }

    const slug = slugify(body.orgName);
    const passwordHash = await hashPassword(body.password);

    // Trial ends 14 days from now for all paid plans
    const trialEndsAt =
      body.plan !== "FREE"
        ? new Date(Date.now() + 14 * 24 * 60 * 60 * 1000)
        : null;

    // Atomic: create tenant + admin user in one transaction
    const { tenant, user } = await prisma.$transaction(async (tx) => {
      const tenant = await tx.tenant.create({
        data: {
          name:        body.orgName,
          slug,
          plan:        body.plan as any,
          status:      trialEndsAt ? "TRIAL" : "ACTIVE",
          trialEndsAt: trialEndsAt ?? undefined,
          industry:    body.industry,
          companySize: body.companySize,
          website:     body.website || undefined,
        },
      });

      const user = await tx.user.create({
        data: {
          tenantId:     tenant.id,
          email:        body.email.toLowerCase(),
          passwordHash,
          firstName:    body.firstName,
          lastName:     body.lastName,
          role:         "ADMIN",
        },
      });

      return { tenant, user };
    });

    const authUser = {
      id:        user.id,
      tenantId:  tenant.id,
      email:     user.email,
      role:      user.role,
      firstName: user.firstName,
      lastName:  user.lastName,
    };

    const accessToken  = generateToken(authUser);
    const refreshToken = signRefreshToken({
      sub:      user.id,
      email:    user.email,
      role:     user.role,
      tenantId: tenant.id,
    });

    res.cookie("ats-token", accessToken, {
      ...COOKIE_OPTS,
      maxAge: 24 * 60 * 60 * 1000,
    });
    res.cookie("ats-refresh", refreshToken, {
      ...COOKIE_OPTS,
      maxAge: 7 * 24 * 60 * 60 * 1000,
    });

    // Batch 3: notify all SUPER_ADMIN users about new tenant signup
    try {
      const { emitNotification } = await import("../lib/notification-bus");
      await emitNotification({
        tenantId: null,
        userId: null,                        // broadcast to all super-admins
        type: "NEW_TENANT_SIGNUP",
        title: `New tenant signed up: ${tenant.name}`,
        body: `Plan: ${tenant.plan}${body.industry ? ` · ${body.industry}` : ""}${body.companySize ? ` · ${body.companySize} employees` : ""}`,
        link: `/admin?tenant=${tenant.id}`,
        metadata: { tenantId: tenant.id, plan: tenant.plan },
      });
    } catch (notifyErr) {
      // Non-fatal — registration already succeeded
      console.warn("[register-company] notification emit failed:", notifyErr);
    }

    ok(res, {
      token:      accessToken,
      refreshToken,
      expiresAt:  new Date(Date.now() + 24 * 60 * 60 * 1000),
      tenant: {
        id:     tenant.id,
        name:   tenant.name,
        slug:   tenant.slug,
        plan:   tenant.plan,
        status: tenant.status,
        trialEndsAt: tenant.trialEndsAt,
      },
      user: {
        id:        user.id,
        email:     user.email,
        name:      `${user.firstName} ${user.lastName}`,
        firstName: user.firstName,
        lastName:  user.lastName,
        role:      user.role,
        tenantId:  tenant.id,
      },
    });
  } catch (err) {
    next(err);
  }
});

export default router;
