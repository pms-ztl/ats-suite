/**
 * Bulk resume upload (Batch 2).
 *
 *  POST /api/resume/bulk           Upload 1..1000 resumes in one request
 *  GET  /api/resume/bulk           List recent bulk uploads for the tenant
 *  GET  /api/resume/bulk/:id       Poll status + per-file errors
 *
 * Flow:
 *   1) Validate plan limits (bulkUploadMax + resumesPerMonth)
 *   2) Create BulkUpload row with status=QUEUED
 *   3) For each file: extract text, upsert Candidate+Resume, enqueue parse job
 *      (with bulkUploadId in payload so the worker can tick progress)
 *   4) Return 202 with statusUrl for client polling
 */
import { Router, Request, Response, NextFunction } from 'express';
import multer from 'multer';
import { requireAuth, getTenantId, requireTenantUser } from '../middleware/auth';
import { AppError } from '../middleware/errorHandler';
import { prisma } from '../utils/prisma';
import { ok, created } from '../lib/response';
import { extractText } from '../lib/document-extractor';
import { enqueueResumeParse } from '../lib/queue';
import { getMonthlyResumeCount } from '../lib/billing';
import { PLAN_LIMITS, canParseMoreResumes } from '../lib/plan-limits';
import logger from '../lib/logger';
import { AuthRequest } from '../types';

const router = Router();
router.use(requireAuth);

// ── Multer config ──────────────────────────────────────────────────────────
// 10MB per file (matches existing single-upload). With max 1000 files at 10MB
// each = up to 10GB per request. multer.memoryStorage() would OOM; we use disk
// storage in os.tmpdir() and read each file's buffer back when we need it.
import os from 'os';
import path from 'path';
import fs from 'fs/promises';

const upload = multer({
  storage: multer.diskStorage({
    destination: os.tmpdir(),
    filename: (_req, file, cb) =>
      cb(null, `bulkupload-${Date.now()}-${Math.random().toString(36).slice(2, 10)}-${file.originalname}`),
  }),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB per file
  fileFilter: (_req, file, cb) => {
    const allowed = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/msword',
      'text/plain',
    ];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error(`Unsupported file type: ${file.mimetype}`));
  },
});

// ── POST /api/resume/bulk ──────────────────────────────────────────────────
router.post(
  '/bulk',
  requireTenantUser,
  upload.array('resumes', 1000),
  async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    const filesToCleanup: string[] = [];
    try {
      const tenantId = getTenantId(req);
      const userId = (req as AuthRequest).user!.id;
      const files = (req.files ?? []) as Express.Multer.File[];
      filesToCleanup.push(...files.map((f) => f.path));
      const requisitionId =
        typeof req.body.requisitionId === 'string' && req.body.requisitionId.length > 0
          ? req.body.requisitionId
          : null;

      if (files.length === 0)
        throw new AppError('VALIDATION_ERROR', 'At least one resume file is required', 400);

      // ── Plan-limit enforcement ──────────────────────────────────────────
      const tenant = await prisma.tenant.findUnique({
        where: { id: tenantId },
        select: { plan: true },
      });
      if (!tenant) throw new AppError('NOT_FOUND', 'Tenant not found', 404);

      const limits = PLAN_LIMITS[tenant.plan];
      if (files.length > limits.bulkUploadMax) {
        throw new AppError(
          'PLAN_LIMIT',
          `Plan ${tenant.plan} allows max ${limits.bulkUploadMax} files per bulk upload. Got ${files.length}.`,
          402
        );
      }

      const monthCount = await getMonthlyResumeCount(tenantId);
      if (!canParseMoreResumes(tenant.plan, monthCount, files.length)) {
        throw new AppError(
          'PLAN_LIMIT',
          `Monthly resume quota (${limits.resumesPerMonth}) reached for plan ${tenant.plan}. Used ${monthCount}, attempting to add ${files.length}. Upgrade to continue.`,
          402
        );
      }

      // ── Create BulkUpload row ───────────────────────────────────────────
      const bulkUpload = await prisma.bulkUpload.create({
        data: {
          tenantId,
          userId,
          requisitionId,
          status: 'QUEUED',
          totalFiles: files.length,
          processedFiles: 0,
          failedFiles: 0,
          errors: [],
        },
      });

      // ── Fan out: create Candidate+Resume per file, enqueue parse ────────
      // We do this sequentially (not Promise.all) to keep DB connection pool
      // happy and to gracefully record errors per-file.
      const enqueued: Array<{ filename: string; resumeId: string; candidateId: string }> = [];
      const failed: Array<{ filename: string; error: string }> = [];

      for (const file of files) {
        try {
          const buffer = await fs.readFile(file.path);
          const extractedText = await extractText(buffer, file.mimetype);

          // Placeholder candidate name from filename (parser will overwrite)
          const baseName = file.originalname
            .replace(/\.(pdf|docx?|txt)$/i, '')
            .replace(/[-_]+/g, ' ')
            .trim();
          const placeholderEmail = `bulk-${bulkUpload.id.slice(0, 8)}-${enqueued.length}@pending.placeholder`;

          const candidate = await prisma.candidate.create({
            data: {
              tenantId,
              email: placeholderEmail,
              firstName: baseName.split(' ')[0] || 'Pending',
              lastName: baseName.split(' ').slice(1).join(' ') || `Parse #${enqueued.length + 1}`,
              source: 'BULK_UPLOAD',
            },
          });

          const resume = await prisma.resume.create({
            data: {
              tenantId,
              candidateId: candidate.id,
              fileName: file.originalname,
              originalFilename: file.originalname,
              fileSize: file.size,
              mimeType: file.mimetype,
              extractedText,
              parseStatus: 'EXTRACTED',
              bulkUploadId: bulkUpload.id,
            },
          });

          // Update candidate.resumeUrl to internal pointer
          await prisma.candidate.update({
            where: { id: candidate.id },
            data: { resumeUrl: `internal://resume/${resume.id}` },
          });

          // Enqueue parse with bulkUploadId so the worker can tick progress
          await enqueueResumeParse({
            candidateId: candidate.id,
            tenantId,
            userId,
            resumeId: resume.id,
            bulkUploadId: bulkUpload.id,
          } as any);

          enqueued.push({ filename: file.originalname, resumeId: resume.id, candidateId: candidate.id });
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          failed.push({ filename: file.originalname, error: msg });
          logger.warn({ err, filename: file.originalname, bulkUploadId: bulkUpload.id }, 'Bulk upload: file failed');
        }
      }

      // If any file failed extraction outright, record them
      if (failed.length > 0) {
        await prisma.bulkUpload.update({
          where: { id: bulkUpload.id },
          data: {
            failedFiles: failed.length,
            errors: failed as any,
            status: failed.length === files.length ? 'FAILED' : 'PROCESSING',
          },
        });
      } else {
        await prisma.bulkUpload.update({
          where: { id: bulkUpload.id },
          data: { status: 'PROCESSING' },
        });
      }

      created(res, {
        bulkUploadId: bulkUpload.id,
        totalFiles: files.length,
        enqueued: enqueued.length,
        failed: failed.length,
        statusUrl: `/api/resume/bulk/${bulkUpload.id}`,
      });
    } catch (err) {
      next(err);
    } finally {
      // Always clean up temp files (even on error)
      for (const p of filesToCleanup) {
        fs.unlink(p).catch(() => {});
      }
    }
  }
);

// ── GET /api/resume/bulk/:id — poll progress ──────────────────────────────
router.get('/bulk/:id', async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const tenantId = getTenantId(req);
    const id = req.params['id'] as string;
    const row = await prisma.bulkUpload.findFirst({ where: { id, tenantId } });
    if (!row) throw new AppError('NOT_FOUND', 'Bulk upload not found', 404);
    ok(res, {
      id: row.id,
      status: row.status,
      totalFiles: row.totalFiles,
      processedFiles: row.processedFiles,
      failedFiles: row.failedFiles,
      progress: row.totalFiles > 0
        ? Math.round(((row.processedFiles + row.failedFiles) / row.totalFiles) * 100)
        : 0,
      errors: row.errors,
      requisitionId: row.requisitionId,
      createdAt: row.createdAt,
      completedAt: row.completedAt,
    });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/resume/bulk — list recent uploads (paginated) ─────────────────
router.get('/bulk', async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const tenantId = getTenantId(req);
    const limit = Math.min(Number(req.query['limit']) || 25, 100);
    const rows = await prisma.bulkUpload.findMany({
      where: { tenantId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    ok(res, rows);
  } catch (err) {
    next(err);
  }
});

export default router;
