-- CreateEnum
CREATE TYPE "BulkUploadStatus" AS ENUM ('QUEUED', 'PROCESSING', 'COMPLETED', 'FAILED', 'PARTIAL');

-- AlterTable
ALTER TABLE "Resume" ADD COLUMN     "bulkUploadId" TEXT;

-- CreateTable
CREATE TABLE "BulkUpload" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "requisitionId" TEXT,
    "status" "BulkUploadStatus" NOT NULL DEFAULT 'QUEUED',
    "totalFiles" INTEGER NOT NULL,
    "processedFiles" INTEGER NOT NULL DEFAULT 0,
    "failedFiles" INTEGER NOT NULL DEFAULT 0,
    "errors" JSONB NOT NULL DEFAULT '[]',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "completedAt" TIMESTAMP(3),

    CONSTRAINT "BulkUpload_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "BulkUpload_tenantId_status_idx" ON "BulkUpload"("tenantId", "status");

-- CreateIndex
CREATE INDEX "BulkUpload_tenantId_createdAt_idx" ON "BulkUpload"("tenantId", "createdAt");

-- CreateIndex
CREATE INDEX "Resume_bulkUploadId_idx" ON "Resume"("bulkUploadId");

-- AddForeignKey
ALTER TABLE "BulkUpload" ADD CONSTRAINT "BulkUpload_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
