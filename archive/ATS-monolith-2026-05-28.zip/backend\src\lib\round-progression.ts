/**
 * Round progression library (Batch 6).
 *
 * Single source of truth for "move an application to its next interview round".
 * Used by BOTH:
 *   - POST /api/applications/:id/advance-round  (user-triggered)
 *   - feedback-advance.worker.ts                (auto-triggered on STRONG_HIRE)
 *
 * Auto-assigns one panelist by round-robin from users matching the round's
 * defaultPanelistRole. Emits a notification if no eligible panelist exists.
 */
import { prisma } from "../utils/prisma";
import logger from "./logger";
import { emitNotification } from "./notification-bus";

export type AdvanceTriggeredBy = "user" | "auto";

export interface AdvanceResult {
  interview: any;        // Prisma.Interview shape
  round: any;            // Prisma.InterviewRound shape
  assignedPanelistId: string | null;
  reason: "scheduled" | "no_more_rounds" | "no_panelist_available";
}

/**
 * Advance an application to its next round. Returns:
 *  - scheduled: created next interview (+ optional panelist)
 *  - no_more_rounds: this was already the last round
 *  - no_panelist_available: scheduled, but no user matched defaultPanelistRole
 */
export async function advanceApplicationToNextRound(args: {
  applicationId: string;
  tenantId: string;
  triggeredBy: AdvanceTriggeredBy;
  triggeredByUserId?: string;
}): Promise<AdvanceResult> {
  const { applicationId, tenantId, triggeredBy } = args;

  const application = await prisma.application.findFirst({
    where: { id: applicationId, tenantId },
    select: { id: true, candidateId: true, requisitionId: true },
  });
  if (!application) throw new Error(`Application ${applicationId} not found in tenant ${tenantId}`);

  // Find latest round
  const lastInterview = await prisma.interview.findFirst({
    where: { applicationId, tenantId, roundId: { not: null } },
    orderBy: [{ roundNumber: "desc" }, { createdAt: "desc" }],
    select: { roundNumber: true },
  });
  const nextOrder = (lastInterview?.roundNumber ?? 0) + 1;

  const nextRound = await prisma.interviewRound.findFirst({
    where: { requisitionId: application.requisitionId, tenantId, order: nextOrder },
  });
  if (!nextRound) {
    return {
      interview: null,
      round: null,
      assignedPanelistId: null,
      reason: "no_more_rounds",
    };
  }

  // Create stub interview for the next round
  const interview = await prisma.interview.create({
    data: {
      tenantId,
      requisitionId: application.requisitionId,
      candidateId: application.candidateId,
      applicationId,
      roundId: nextRound.id,
      roundNumber: nextRound.order,
      type: nextRound.interviewType,
      interviewType: nextRound.interviewType,
      stage: nextRound.name,
      duration: nextRound.durationMinutes,
      status: "SCHEDULED" as any,
    },
  });

  // ── Round-robin panelist auto-assign ─────────────────────────────────────
  let assignedPanelistId: string | null = null;
  let reason: AdvanceResult["reason"] = "scheduled";

  if (nextRound.defaultPanelistRole) {
    const candidates = await prisma.user.findMany({
      where: {
        tenantId,
        role: nextRound.defaultPanelistRole as any,
        isActive: true,
      },
      select: { id: true },
    });

    if (candidates.length === 0) {
      reason = "no_panelist_available";
      // Notify tenant admins that this round needs manual panel assignment
      await emitNotification({
        tenantId,
        userId: null,
        type: "SYSTEM",
        title: `Round ${nextRound.order} needs a panelist`,
        body: `No active users with role ${nextRound.defaultPanelistRole}. Please assign manually.`,
        link: `/interviews/${interview.id}`,
        metadata: {
          interviewId: interview.id,
          roundId: nextRound.id,
          neededRole: nextRound.defaultPanelistRole,
        },
      }).catch((err) => logger.warn({ err }, "Round-needs-panelist notification failed"));
    } else {
      // Round-robin: pick the user whose MOST RECENT panel assignment is the oldest
      // (or who has never been on a panel). Order by most-recent-panel-assignment ASC.
      const lastAssignedByUser = await prisma.interviewPanelMember.groupBy({
        by: ["userId"],
        where: { userId: { in: candidates.map((c) => c.id) } },
        _max: { id: true },     // proxy for "last assignment" — InterviewPanelMember has no createdAt
      });

      // Build a map of userId → last InterviewPanelMember.id (lexicographic UUID is
      // not chronological, so we'll re-query that row's interview.createdAt below)
      const lastIdByUser = new Map<string, string>();
      for (const row of lastAssignedByUser) {
        if (row._max.id) lastIdByUser.set(row.userId, row._max.id);
      }

      // Resolve to interview.createdAt for true chronological ordering
      const ids = [...lastIdByUser.values()];
      const lastAssignments = ids.length > 0
        ? await prisma.interviewPanelMember.findMany({
            where: { id: { in: ids } },
            select: { id: true, userId: true, interview: { select: { createdAt: true } } },
          })
        : [];
      const lastTsByUser = new Map<string, Date>();
      for (const a of lastAssignments) {
        lastTsByUser.set(a.userId, a.interview.createdAt);
      }

      // Users with NO prior assignment come first (epoch=0), then sort ASC by lastTs
      const sorted = candidates
        .map((c) => ({
          userId: c.id,
          lastTs: lastTsByUser.get(c.id) ?? new Date(0),
        }))
        .sort((a, b) => a.lastTs.getTime() - b.lastTs.getTime());

      const picked = sorted[0]!.userId;

      await prisma.interviewPanelMember.create({
        data: {
          interviewId: interview.id,
          userId: picked,
          role: nextRound.defaultPanelistRole as any,
          isRequired: true,
          confirmed: false,
        },
      });
      assignedPanelistId = picked;
    }
  }

  logger.info(
    {
      applicationId,
      roundId: nextRound.id,
      roundOrder: nextRound.order,
      interviewId: interview.id,
      assignedPanelistId,
      triggeredBy,
      reason,
    },
    "Application advanced to next round"
  );

  return { interview, round: nextRound, assignedPanelistId, reason };
}
