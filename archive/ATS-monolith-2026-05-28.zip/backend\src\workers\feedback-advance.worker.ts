/**
 * Feedback-advance worker (Batch 6 Gap 1).
 *
 * Listens on the `interview-feedback` queue. For each submitted feedback:
 *   1. ALWAYS emit `INTERVIEW_FEEDBACK_NEW` notification to tenant admins
 *      (so they know feedback arrived regardless of auto-advance behavior)
 *   2. If feedback.recommendation === "STRONG_HIRE" AND parent round's
 *      `autoAdvanceOnPass === true`, call advanceApplicationToNextRound()
 *      which creates the next round's interview AND round-robin assigns a
 *      panelist by `defaultPanelistRole`.
 *
 * Threshold is STRICT: HIRE alone is NOT enough — tenant must explicitly
 * advance HIRE candidates so they have a chance to discuss borderline cases.
 */
import { Worker, Job } from "bullmq";
import {
  getRedisConnection,
  QUEUE_NAMES,
  FeedbackProcessedJobData,
} from "../lib/queue";
import { prisma } from "../utils/prisma";
import { advanceApplicationToNextRound } from "../lib/round-progression";
import { emitNotification } from "../lib/notification-bus";
import logger from "../lib/logger";

const AUTO_ADVANCE_THRESHOLD = "STRONG_HIRE"; // strict per user decision

export function startFeedbackAdvanceWorker(): Worker {
  const worker = new Worker<FeedbackProcessedJobData>(
    QUEUE_NAMES.FEEDBACK_PROCESSED,
    async (job: Job<FeedbackProcessedJobData>) => {
      const { feedbackId, interviewId, tenantId, interviewerId } = job.data;

      logger.info({ jobId: job.id, feedbackId, interviewId }, "Processing feedback-advance job");

      // Load feedback + interview + round in one shot
      const feedback = await prisma.interviewFeedback.findFirst({
        where: { id: feedbackId },
        include: {
          interview: {
            include: {
              round: true,
              application: { select: { id: true, candidateId: true } },
            },
          },
          candidate: { select: { firstName: true, lastName: true } },
        },
      });

      if (!feedback) {
        logger.warn({ feedbackId }, "Feedback not found — skipping");
        return { skipped: "feedback_not_found" };
      }

      const interview = feedback.interview;
      const round = interview.round;
      const candidateName = `${feedback.candidate.firstName} ${feedback.candidate.lastName}`.trim();

      // ── 1. Always notify tenant admins about new feedback ────────────────
      try {
        await emitNotification({
          tenantId,
          userId: null,
          type: "INTERVIEW_FEEDBACK_NEW",
          title: `New interview feedback: ${candidateName}`,
          body: `Recommendation: ${feedback.recommendation}${round ? ` · Round ${interview.roundNumber} (${round.name})` : ""}`,
          link: `/interviews/${interviewId}`,
          metadata: {
            feedbackId,
            interviewId,
            recommendation: feedback.recommendation,
            roundId: round?.id ?? null,
          },
        });
      } catch (err) {
        logger.warn({ err, feedbackId }, "Feedback notification emit failed (non-fatal)");
      }

      // ── 2. Auto-advance gate ─────────────────────────────────────────────
      if (!round) {
        return { autoAdvanced: false, reason: "no_round" };
      }
      if (!round.autoAdvanceOnPass) {
        return { autoAdvanced: false, reason: "auto_advance_disabled" };
      }
      if (feedback.recommendation !== AUTO_ADVANCE_THRESHOLD) {
        return { autoAdvanced: false, reason: `threshold_not_met (got ${feedback.recommendation})` };
      }
      if (!interview.application) {
        return { autoAdvanced: false, reason: "no_application_link" };
      }

      // ── 3. Advance ───────────────────────────────────────────────────────
      try {
        const result = await advanceApplicationToNextRound({
          applicationId: interview.application.id,
          tenantId,
          triggeredBy: "auto",
          triggeredByUserId: interviewerId,
        });

        if (result.reason === "no_more_rounds") {
          // Notify that candidate has finished all rounds
          await emitNotification({
            tenantId,
            userId: null,
            type: "SYSTEM",
            title: `${candidateName} cleared all rounds`,
            body: `Final round PASS received. Ready for offer decision.`,
            link: `/candidates/${feedback.candidate}`,
            metadata: { feedbackId, interviewId, candidateName },
          }).catch(() => {});
          return { autoAdvanced: false, reason: "no_more_rounds" };
        }

        // Notify about the next round being scheduled
        await emitNotification({
          tenantId,
          userId: null,
          type: "SYSTEM",
          title: `Auto-advanced: ${candidateName} → Round ${result.round.order}`,
          body: `${result.round.name} (${result.round.durationMinutes}min)${result.assignedPanelistId ? " · panelist assigned" : ""}`,
          link: `/interviews/${result.interview.id}`,
          metadata: {
            feedbackId,
            advancedToInterviewId: result.interview.id,
            roundOrder: result.round.order,
          },
        }).catch(() => {});

        return {
          autoAdvanced: true,
          nextInterviewId: result.interview.id,
          roundOrder: result.round.order,
          assignedPanelistId: result.assignedPanelistId,
        };
      } catch (err) {
        logger.error({ err, feedbackId }, "Auto-advance failed");
        throw err; // BullMQ will retry per the queue's backoff policy
      }
    },
    {
      connection: getRedisConnection(),
      concurrency: 5,
      limiter: { max: 30, duration: 60_000 },  // 30 jobs/min — plenty for feedback volume
    }
  );

  worker.on("completed", (job) => {
    logger.info({ jobId: job.id, result: job.returnvalue }, "Feedback-advance job completed");
  });
  worker.on("failed", (job, err) => {
    logger.error(
      { jobId: job?.id, error: err.message, attempts: job?.attemptsMade },
      "Feedback-advance job failed"
    );
  });

  return worker;
}
