-- AlterTable
ALTER TABLE "Tenant" ADD COLUMN     "usageQuota" JSONB NOT NULL DEFAULT '{}';
