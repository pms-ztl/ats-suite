/**
 * /api/super-admin/* — Platform-level tenant management.
 * Protected by:  role === SUPER_ADMIN  OR  X-Super-Admin-Key header
 *                matching SUPER_ADMIN_SECRET env var.
 */
import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import prisma from "../utils/prisma";
import { AppError } from "../middleware/errorHandler";
import { ok } from "../lib/response";
import { AuthRequest } from "../types";

const router = Router();

// ── Guard: SUPER_ADMIN role OR secret key header ────────────────────────────
// Logged-in SUPER_ADMIN users hit this guard normally; CLI / cron tools that
// don't have a JWT can pass `X-Super-Admin-Key: $SUPER_ADMIN_SECRET` instead.
function superAdminGate(req: Request, _res: Response, next: NextFunction) {
  const authReq = req as AuthRequest;
  const secretKey = process.env["SUPER_ADMIN_SECRET"];

  if (authReq.user?.role === "SUPER_ADMIN") return next();

  if (secretKey && req.headers["x-super-admin-key"] === secretKey) {
    return next();
  }

  next(new AppError("FORBIDDEN", "Super-admin access required", 403));
}

router.use(superAdminGate);

// ── GET /api/super-admin/tenants ────────────────────────────────────────────
router.get("/tenants", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page  = Number(req.query.page)  || 1;
    const limit = Number(req.query.limit) || 25;
    const plan  = typeof req.query.plan   === "string" ? req.query.plan   : undefined;
    const status = typeof req.query.status === "string" ? req.query.status : undefined;
    const search = typeof req.query.search === "string" ? req.query.search : undefined;

    const where: any = {};
    if (plan)   where.plan   = plan.toUpperCase();
    if (status) where.status = status.toUpperCase();
    if (search) {
      where.OR = [
        { name:  { contains: search, mode: "insensitive" } },
        { slug:  { contains: search, mode: "insensitive" } },
        { website: { contains: search, mode: "insensitive" } },
      ];
    }

    const [total, tenants] = await Promise.all([
      prisma.tenant.count({ where }),
      prisma.tenant.findMany({
        where,
        skip:    (page - 1) * limit,
        take:    limit,
        orderBy: { createdAt: "desc" },
        include: {
          _count: {
            select: {
              users:        true,
              requisitions: true,
              candidates:   true,
              agentRuns:    true,
            },
          },
        },
      }),
    ]);

    // Attach 30-day agent cost per tenant
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const costRows = await prisma.agentRun.groupBy({
      by:     ["tenantId"],
      where:  { tenantId: { in: tenants.map((t) => t.id) }, createdAt: { gte: thirtyDaysAgo } },
      _sum:   { costUsd: true },
    });
    const costMap = Object.fromEntries(
      costRows.map((r) => [r.tenantId, Number(r._sum.costUsd ?? 0)])
    );

    const enriched = tenants.map((t) => ({
      id:          t.id,
      name:        t.name,
      slug:        t.slug,
      plan:        t.plan,
      status:      t.status,
      trialEndsAt: t.trialEndsAt,
      industry:    t.industry,
      companySize: t.companySize,
      website:     t.website,
      logoUrl:     t.logoUrl,
      dataRegion:  t.dataRegion,
      createdAt:   t.createdAt,
      userCount:       t._count.users,
      requisitionCount: t._count.requisitions,
      candidateCount:   t._count.candidates,
      agentRunCount:    t._count.agentRuns,
      costUsd30d:  costMap[t.id] ?? 0,
    }));

    ok(res, {
      data:  enriched,
      total,
      page,
      pages: Math.ceil(total / limit),
    });
  } catch (err) {
    next(err);
  }
});

// ── GET /api/super-admin/tenants/:id ───────────────────────────────────────
router.get("/tenants/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params["id"] as string;
    const tenant = await prisma.tenant.findUnique({
      where: { id },
      include: {
        users: {
          select: { id: true, email: true, firstName: true, lastName: true, role: true, isActive: true, lastLoginAt: true },
          orderBy: { createdAt: "asc" },
        },
        _count: {
          select: { requisitions: true, candidates: true, agentRuns: true },
        },
      },
    });
    if (!tenant) throw new AppError("NOT_FOUND", "Tenant not found", 404);

    ok(res, tenant);
  } catch (err) {
    next(err);
  }
});

// ── PATCH /api/super-admin/tenants/:id ─────────────────────────────────────
const UpdateTenantSchema = z.object({
  plan:        z.enum(["FREE", "STARTER", "PROFESSIONAL", "ENTERPRISE"]).optional(),
  status:      z.enum(["TRIAL", "ACTIVE", "SUSPENDED", "CANCELLED"]).optional(),
  name:        z.string().min(2).max(100).optional(),
  industry:    z.string().optional(),
  companySize: z.string().optional(),
  dataRegion:  z.string().optional(),
});

router.patch("/tenants/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params["id"] as string;
    const body = UpdateTenantSchema.parse(req.body);
    const tenant = await prisma.tenant.update({
      where: { id },
      data:  body as any,
    });
    ok(res, tenant);
  } catch (err) {
    next(err);
  }
});

// ── GET /api/super-admin/stats ──────────────────────────────────────────────
router.get("/stats", async (_req: Request, res: Response, next: NextFunction) => {
  try {
    const [
      totalTenants, activeTenants, trialTenants,
      planCounts, totalUsers, totalCandidates,
      totalRequisitions, recentTenants,
    ] = await Promise.all([
      prisma.tenant.count(),
      prisma.tenant.count({ where: { status: "ACTIVE" } }),
      prisma.tenant.count({ where: { status: "TRIAL" } }),
      prisma.tenant.groupBy({ by: ["plan"], _count: { _all: true } }),
      prisma.user.count(),
      prisma.candidate.count(),
      prisma.requisition.count(),
      prisma.tenant.findMany({
        take: 5,
        orderBy: { createdAt: "desc" },
        select: { id: true, name: true, plan: true, status: true, createdAt: true },
      }),
    ]);

    // 30-day revenue (cost) across all tenants
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const costAgg = await prisma.agentRun.aggregate({
      where: { createdAt: { gte: thirtyDaysAgo } },
      _sum:  { costUsd: true },
    });

    ok(res, {
      totalTenants,
      activeTenants,
      trialTenants,
      suspendedTenants: await prisma.tenant.count({ where: { status: "SUSPENDED" } }),
      planBreakdown: Object.fromEntries(planCounts.map((p) => [p.plan, p._count._all])),
      totalUsers,
      totalCandidates,
      totalRequisitions,
      totalCostUsd30d: Number(costAgg._sum.costUsd ?? 0),
      recentTenants,
    });
  } catch (err) {
    next(err);
  }
});

// ── DELETE /api/super-admin/tenants/:id (soft — set CANCELLED) ─────────────
router.delete("/tenants/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params["id"] as string;
    await prisma.tenant.update({
      where: { id },
      data:  { status: "CANCELLED" as any },
    });
    ok(res, { message: "Tenant cancelled" });
  } catch (err) {
    next(err);
  }
});

// ═════════════════════════════════════════════════════════════════════════
// Batch 3: Plan upgrade approval queue (super-admin side)
// ═════════════════════════════════════════════════════════════════════════
import { emitNotification } from "../lib/notification-bus";

// ── GET /api/super-admin/plan-change-requests ──────────────────────────────
router.get("/plan-change-requests", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = typeof req.query["status"] === "string" ? req.query["status"] : "PENDING";
    const rows = await prisma.planChangeRequest.findMany({
      where: { status: status as any },
      orderBy: { requestedAt: "desc" },
      include: {
        tenant: { select: { id: true, name: true, slug: true, plan: true, status: true } },
      },
    });
    ok(res, rows);
  } catch (err) {
    next(err);
  }
});

// ── PATCH /api/super-admin/plan-change-requests/:id ────────────────────────
// body: { action: "APPROVE" | "REJECT", note?: string }
import { z as zod } from "zod";
const ReviewSchema = zod.object({
  action: zod.enum(["APPROVE", "REJECT"]),
  note:   zod.string().max(500).optional(),
});

router.patch("/plan-change-requests/:id", async (req: Request, res: Response, next: NextFunction) => {
  try {
    const id = req.params["id"] as string;
    const reviewerId = (req as AuthRequest).user?.id ?? "system";
    const { action, note } = ReviewSchema.parse(req.body);

    const request = await prisma.planChangeRequest.findUnique({
      where: { id },
      include: { tenant: { select: { id: true, name: true } } },
    });
    if (!request) throw new AppError("NOT_FOUND", "Plan change request not found", 404);
    if (request.status !== "PENDING") {
      throw new AppError("VALIDATION_ERROR", `Cannot review a request in ${request.status} state.`, 400);
    }

    const newStatus = action === "APPROVE" ? "APPROVED" : "REJECTED";

    // Atomic: update PCR + tenant.plan + emit notification
    const result = await prisma.$transaction(async (tx) => {
      const updated = await tx.planChangeRequest.update({
        where: { id },
        data: {
          status: newStatus as any,
          reviewedByUserId: reviewerId,
          reviewedAt: new Date(),
          decisionNote: note ?? null,
        },
      });

      if (action === "APPROVE") {
        await tx.tenant.update({
          where: { id: request.tenantId },
          data: { plan: request.toPlan, status: "ACTIVE" as any },
        });
      }
      return updated;
    });

    // Notify tenant admins of the decision
    await emitNotification({
      tenantId: request.tenantId,
      userId: null,                                // broadcast to all tenant users
      type: action === "APPROVE" ? "PLAN_CHANGE_APPROVED" : "PLAN_CHANGE_REJECTED",
      title:
        action === "APPROVE"
          ? `Plan upgraded to ${request.toPlan}!`
          : `Plan change request was declined`,
      body:
        action === "APPROVE"
          ? `Your tenant is now on the ${request.toPlan} plan.`
          : note ?? "Please contact support for details.",
      link: "/billing",
      metadata: { requestId: id, fromPlan: request.fromPlan, toPlan: request.toPlan, action },
    });

    ok(res, result);
  } catch (err) {
    next(err);
  }
});

export default router;
