-- AlterTable
ALTER TABLE "Interview" ADD COLUMN     "roundId" TEXT,
ADD COLUMN     "roundNumber" INTEGER;

-- CreateTable
CREATE TABLE "InterviewRound" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "requisitionId" TEXT,
    "name" TEXT NOT NULL,
    "order" INTEGER NOT NULL,
    "interviewType" "InterviewType" NOT NULL,
    "durationMinutes" INTEGER NOT NULL DEFAULT 60,
    "instructions" TEXT,
    "autoAdvanceOnPass" BOOLEAN NOT NULL DEFAULT false,
    "defaultPanelistRole" "UserRole",
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "InterviewRound_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "InterviewRound_tenantId_idx" ON "InterviewRound"("tenantId");

-- CreateIndex
CREATE INDEX "InterviewRound_requisitionId_idx" ON "InterviewRound"("requisitionId");

-- CreateIndex
CREATE UNIQUE INDEX "InterviewRound_requisitionId_order_key" ON "InterviewRound"("requisitionId", "order");

-- CreateIndex
CREATE INDEX "Interview_roundId_idx" ON "Interview"("roundId");

-- AddForeignKey
ALTER TABLE "InterviewRound" ADD CONSTRAINT "InterviewRound_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "Tenant"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Interview" ADD CONSTRAINT "Interview_roundId_fkey" FOREIGN KEY ("roundId") REFERENCES "InterviewRound"("id") ON DELETE SET NULL ON UPDATE CASCADE;
