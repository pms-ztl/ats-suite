/**
 * Plan limits — single source of truth for SaaS plan enforcement.
 *
 * Used by:
 *  - Batch 1: seat-limit middleware (users.ts /invite), plan-gated agents (billing.ts)
 *  - Batch 2: bulk upload quota (resume-bulk.ts)
 *  - Batch 4: form builder "premium fields" gating
 *
 * -1 means unlimited. Agent list "ALL" means every agent registered in
 * AGENT_DEFINITIONS is enabled.
 */
import type { TenantPlan } from "../../node_modules/.prisma/client/enums";

export interface PlanLimits {
  seats:           number;   // max active users in tenant
  activeJobs:      number;   // max OPEN requisitions
  resumesPerMonth: number;   // parse quota per calendar month
  bulkUploadMax:   number;   // max files per /api/resume/bulk request
  agents:          readonly string[] | "ALL";
  sla:             string;   // human-readable SLA label
  customForms:     boolean;  // Batch 4 form builder access
  configurableRounds: boolean; // Batch 5 interview rounds
}

export const PLAN_LIMITS: Record<TenantPlan, PlanLimits> = {
  FREE: {
    seats: 1,
    activeJobs: 3,
    resumesPerMonth: 10,
    bulkUploadMax: 25,
    agents: ["resume-parser"],
    sla: "Best-effort",
    customForms: false,
    configurableRounds: false,
  },
  STARTER: {
    seats: 5,
    activeJobs: 20,
    resumesPerMonth: 500,
    bulkUploadMax: 100,
    agents: ["resume-parser", "candidate-screener", "interview-scheduler"],
    sla: "99.0%",
    customForms: true,
    configurableRounds: true,
  },
  PROFESSIONAL: {
    seats: 15,
    activeJobs: -1,
    resumesPerMonth: 5000,
    bulkUploadMax: 500,
    agents: "ALL",
    sla: "99.9%",
    customForms: true,
    configurableRounds: true,
  },
  ENTERPRISE: {
    seats: -1,
    activeJobs: -1,
    resumesPerMonth: -1,
    bulkUploadMax: 1000,
    agents: "ALL",
    sla: "99.99% + 24/7 phone",
    customForms: true,
    configurableRounds: true,
  },
} as const;

export function isUnlimited(n: number): boolean {
  return n === -1;
}

/** Returns true if the plan allows the given agent type. */
export function isPlanAgentEnabled(plan: TenantPlan, agentType: string): boolean {
  const allowed = PLAN_LIMITS[plan].agents;
  if (allowed === "ALL") return true;
  return allowed.includes(agentType);
}

/** Returns true if the plan can accept N more seats (i.e., current + N <= max). */
export function canAddSeats(plan: TenantPlan, currentSeats: number, addingN = 1): boolean {
  const limit = PLAN_LIMITS[plan].seats;
  if (isUnlimited(limit)) return true;
  return currentSeats + addingN <= limit;
}

/** Returns true if the plan can accept N more resume parses this month. */
export function canParseMoreResumes(plan: TenantPlan, monthCount: number, addingN = 1): boolean {
  const limit = PLAN_LIMITS[plan].resumesPerMonth;
  if (isUnlimited(limit)) return true;
  return monthCount + addingN <= limit;
}

/** Friendly plan label. */
export function planLabel(plan: TenantPlan): string {
  const labels: Record<string, string> = {
    FREE: "Free",
    STARTER: "Starter",
    PROFESSIONAL: "Professional",
    ENTERPRISE: "Enterprise",
  };
  return labels[plan] ?? plan;
}
